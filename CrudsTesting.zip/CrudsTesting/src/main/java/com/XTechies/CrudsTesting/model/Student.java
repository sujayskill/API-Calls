package com.XTechies.CrudsTesting.model;


//@Entity
//@Data
public class Student {
	
//	@IdsneratedValue( strategy = GenerationType.AUTO)
	int id;
	String Student;
	
}
