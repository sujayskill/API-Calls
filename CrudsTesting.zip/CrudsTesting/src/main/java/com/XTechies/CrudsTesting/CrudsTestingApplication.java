package com.XTechies.CrudsTesting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudsTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudsTestingApplication.class, args);
	}

}
