package com.XTechies.CrudsTesting.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.XTechies.CrudsTesting.Repository.SignupRepository;
import com.XTechies.CrudsTesting.model.User;

@Service
public class SignupService {

    @Autowired
    private SignupRepository signupDataRepository;

    public List<User> getAllSignupData() {
        return signupDataRepository.findAll();
    }

    public Optional<User> getSignupDataById(int id) {
        return signupDataRepository.findById(id);
    }

    public User saveSignupData(User signupData) {
        return signupDataRepository.save(signupData);
    }

    public User updateSignupData(int id, User updatedData) {
        if (signupDataRepository.existsById(id)) {
            updatedData.setSerialNumber(id);
            return signupDataRepository.save(updatedData);
        }
        return null;
    }

    public void deleteSignupData(int id) {
        signupDataRepository.deleteById(id);
    }
}
