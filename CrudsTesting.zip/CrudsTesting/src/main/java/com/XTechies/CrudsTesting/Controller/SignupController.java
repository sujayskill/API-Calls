package com.XTechies.CrudsTesting.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.XTechies.CrudsTesting.Service.SignupService;
import com.XTechies.CrudsTesting.model.User;

@Controller
@RequestMapping("/Home/Users")
public class SignupController {
	
	@Autowired
	SignupService signupService =new SignupService(); 
	
    @GetMapping("/Signup")
    public String showSignUpForm(Model model) {
      model.addAttribute("user", new User()); // Empty user object for form binding
      return "Signup"; // Return view name
    }

    @PostMapping("/Signup")
    public String processSignUp(@ModelAttribute User user) {
      // Implement logic to save user data (e.g., call a service)
    	signupService.saveSignupData(user);
      return "redirect:/Home/Users/Signup"; // Redirect to success page on successful signup
    }
	
	@GetMapping("/UserDetails")
	public String showUserDetails(Model model) {
//		Model model = new Model("Signup");
		List<User> list = signupService.getAllSignupData();
		model.addAttribute("UserList", list);
		return "UserList";
	}
	
}
