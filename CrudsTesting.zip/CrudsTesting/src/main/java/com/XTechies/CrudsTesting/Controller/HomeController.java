package com.XTechies.CrudsTesting.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.XTechies.CrudsTesting.Service.SignupService;

@Controller
@RequestMapping("/Home")
public class HomeController {
	
	@Autowired
	SignupService signupService =new SignupService(); 

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("message","Digi VERIFY");
        return "home";  // The name of the Thymeleaf template without the .html extension
    }
    
    @GetMapping("/Signin")
    public String signIn() {
        return "/Signin";
    }
}

