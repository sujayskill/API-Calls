package com.XTechies.ApiCalls;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiCallsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiCallsApplication.class, args);
	}

}
