package com.XTechies.ApiCalls.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CallsService {

//	@Value("${imdb.api.key}")
//	private String apiKey = "07ad4a8ae0msh6c3d04a8853985fp12ba8djsna7cb8b508d1f";

//	@Value("${imdb.api.host}")
	private String apiHost = "imdb8.p.rapidapi.com";

	public List<String> getActorsBornToday() {
		String baseUrl = "http://" + apiHost;
		String url = baseUrl + "/actors/list-born-today?month=7&day=27";

		RestTemplate restTemplate = new RestTemplate();
		List<String> result = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<String>>() {
                }).getBody();

        return result;
	}

}
