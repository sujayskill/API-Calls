package com.XTechies.ApiCalls.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.XTechies.ApiCalls.Service.CallsService;

@RestController
@RequestMapping("api/imdb")
public class CallsController {

	@Autowired
	private final CallsService imdbService;

    
    public CallsController(CallsService imdbService) {
        this.imdbService = imdbService;
    }

    @GetMapping("/actors/born-today")
    public List<String> getActorsBornToday() {
        return imdbService.getActorsBornToday();
    }
}
