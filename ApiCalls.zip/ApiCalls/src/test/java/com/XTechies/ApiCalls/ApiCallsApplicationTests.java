package com.XTechies.ApiCalls;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiCallsApplicationTests {

	@Test
	void contextLoads() {
	}

}
